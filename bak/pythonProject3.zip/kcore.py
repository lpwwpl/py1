from PyQt5.QtCore import *
from bitarray import bitarray
import goto
import json
import kdata
from dominate.tags import label
class Core(QThread):
    signalUpdateRobot = pyqtSignal()
    signalUpdatePLC = pyqtSignal()
    def __init__(self, parent=None):
        super(Core, self).__init__(parent)
        self.working = True

    def __del__(self):
        self.working = False

    def run(self):
        while self.working == True:
            self.pickc1()
            break

    def slotUpdatePLCSigs(self):
        msg = kdata.jqr_msg.decode('utf-8')
        data = json.loads(msg)
        for (k,v) in data.items():
            k = int(k)
            matches = [x for x in kdata.dictlist if self.find_by_plc_num(x, k)]
            if(k>=10001 and k <= 10046):
                k = k - 10001
                kdata.input_plc[k] = v
            if(k>=20005 and k<= 20039):
                kdata.out_plc_change[k] = 1
                k = k - 20001
                kdata.out_plc[k] = v
                if (len(matches) > 0):
                    dict = matches[0]
                    idx = int(dict['robot'])
                    if (idx >= 1001):
                        idx = idx - 1001
                    else:
                        continue
                    kdata.input[idx] = v
            elif(k in (20001,20002,20003,20004)):
                kdata.plc_20001_to_20004[k]=v
        self.signalUpdatePLC.emit()



    def sig(self,num):
        if(num>=kdata.in_start):
            return kdata.input[num - kdata.in_start] == 1
        elif num>=kdata.out_start:
            return kdata.output[num - kdata.out_start] == 1

    def bits(self, bit_start, bit_nums):
        start_bit = 0
        end_bit = 0
        if(bit_start >= kdata.in_start):
            start_bit = bit_start - kdata.in_start
            end_bit = start_bit + bit_nums  - 1
            return kdata.input[start_bit: end_bit]
        else:
            start_bit = bit_start - kdata.out_start
            end_bit = start_bit + bit_nums - 1
            return kdata.output[start_bit:end_bit]

    def bits_assign(self, value, bit_start, bit_nums):
        value_str = bin(value).replace('0b', '')
        value = value_str.zfill(bit_nums)

        start_bit = 0
        end_bit = 0
        if(bit_start >= kdata.in_start):
            start_bit = bit_start - kdata.in_start
            end_bit = start_bit + bit_nums - 1
            kdata.input[start_bit : end_bit] = bitarray(value)
        else:
            start_bit = bit_start - kdata.out_start
            end_bit = start_bit + bit_nums - 1
            kdata.output[start_bit: end_bit] = bitarray(value)

    def rposnum(self):
        label .x558
        kdata.posnum = 2
        if kdata.posnum <= 0 or kdata.posnum > 66:
            self.twait(0.5)
            goto .x558
        else:
            print(kdata.posnum)
        if kdata.posnum % 2 == 1:
            jonum = 1
        else:
            jonum = 2

    # freecad jmove
    def jmove(self, param, jonum):
        pass
        # Gui.applcation.....
        # print(param[jonum])

    def pause(self):
        pass

    def continue_(self):
        pass

    def find_by_plc_num(self,x,num):
        plc = int(x['plc'])
        return (plc == num)

    def find_by_robot_num(self,x,num):
        plc = int(x['robot'])
        return (plc == num)

    def signal_plc(self, updateUI=False, *array):
        for number in array:
            num = int(number)
            num_abs = abs(num)
            matches = [x for x in kdata.dictlist if self.find_by_plc_num(x,num_abs)]
            if (len(matches) > 0):
                dict = matches[0]
                plc_idx = num_abs
                robot_idx = int(dict['robot'])
                if (plc_idx >= 20001):
                    plc_idx = plc_idx - 20001
                else:
                    continue
                if (robot_idx >= 1001):
                    robot_idx = robot_idx - 1001
                else:
                    continue
                if num < 0:
                    kdata.out_plc[plc_idx] = 0
                    kdata.input[robot_idx] = 0
                else:
                    kdata.out_plc[plc_idx] = 1
                    kdata.input[robot_idx] = 1
        if (updateUI):
            self.signalUpdatePLC.emit()
            # self.signalUpdateRobot.emit()

    def signal(self, updateUI=False, *array):
        for number in array:
            num = int(number)
            num_abs = abs(num)
            matches = [x for x in kdata.dictlist if self.find_by_robot_num(x, num_abs)]
            if (len(matches) > 0):
                dict = matches[0]
                idx = int(dict['plc'])
                if (idx >= 10001):
                    idx = idx - 10001
                else:
                    continue
            else:
                continue
            kdata.out_robot_change[num_abs] = 1
            if num < 0:
                kdata.output[num_abs - 1] = 0
                kdata.input_plc[idx] = 0
            else:
                kdata.output[num_abs - 1] = 1
                kdata.input_plc[idx] = 1

        if (updateUI):
            self.signalUpdateRobot.emit()
            # self.signalUpdatePLC.emit()

    # freecad lmove
    def lmove(self, param, posnum):
        pass

    # freecad draw
    def draw(self, param):
        pass # array

    # freecad break_
    def break_(self):
        # 等
        pass

    def swait(self,*array):
        flag = False
        while True:
            if(flag):
                break
            flag = True
            self.sleep(2)
            for number in array:
                num = int(number)
                num_abs = abs(num)
                if (num < 0):
                    kdata.swait_dict[num_abs] = 0
                else:
                    kdata.swait_dict[num_abs] = 1
                num_abs = num_abs - kdata.in_start
                if (num < 0 and kdata.input[num_abs] == 0) or (num > 0 and kdata.input[num_abs] == 1):
                    flag = flag & True
                else:
                    flag = flag & False

    def twait(self, num):
        counter = 0
        while True:
            if counter>=num:
                break
            self.sleep(1)
            counter = counter + 1

    # freecad lappro
    def lappro(self, param, posnum, num):
        pass

    # freecad drive
    def drive(self, *array):
        pass

    # freecad tdraw
    def tdraw(self):
        pass

    # freecad here
    def here(self):
        pass

    def rpicknum(self):
        label .x632
        # picknum = self.bits(1185,8)
        picknum = 1
        if(picknum < 0) or (picknum > 48):
            self.twait(0.5)
            goto .x632
        else:
            print(picknum)

    def weight(self):
        pass

    def pickc4f(self):
        pass

    def pickc4q(self):
        self.rpicknum()
        # BASE NULL
        TOOL = kdata.tooltet_k
        self.weight()
        # ACCURACY 100 ALWAYS
        # SPEED 100 ALWAYS
        if kdata.picknum == 0:
            # LAPPRO dg[posnum*10+1],650
            self.signal(1,-2,-255,236)
            # SPEED 20
            # ACCURACY 1 FINE
        else:
            pass

    def pickc3(self):
        pass

    def pickc2(self):
        # BASE NULL
        TOOL = kdata.tooltet_k
        # ACCURACY 100 ALWAYS
        # SPEED 100 ALWAYS
        # ACCURACY 10
        # self.jappro fqq[posnum],222
        # ACCURACY 1 FINE
        # lmove() fqq[posnum];放气位置点
        # twait
        # swait 1197
        # accuracy 10
        # jappro fqq[posnum],222
        # signal(1,-2,-222,-221)
        # swait(1001,-1002)
        # accuracy 1f
        # jmove qmlfront1[jonum]
        # signal(237)
        # lmove mldzx[posnum]
        # speed 50
        # accuracy 1 fine
        # lmove qml[posnum]
        # signal(-1,2)
        # twait(0.2)
        # swait(-1001,1002,1003)
        # lmove mldzx[posnum]
        # accuracy 50
        # jmove qmlfront4[posnum]
        label .replay1
        if self.sig(1003):
            self.signal(-232)
        else:
            self.signal(232)
            self.pause()
            goto .replay1
        # accuracy 100 always
        # speed 70 always
        self.jmove(kdata._pounce, kdata.jobnum) #pounce[jobnum]
        self.signal(-214,-237)


    def tool(self,value,str):
        pass

    def accuracy(self,num):
        pass

    def speed(self,num):
        pass

    def lappro(self):
        pass

    def jappro(self):
        pass

    def shift(self,param,x,y,z):
        pass

    def point(self):
        pass

    #最上面为第一层序号1 - 16
    #中间为第二层序号17 - 32
    #使用粗定位值为最下面一层
    #如果最下面一层未识别使用最上面一层数据
    def pickf(self):
        # BASE NULL
        # tool()
        self.speed(100)
        self.accuracy(100)
        label .x160
        self.rpalletnum()   #读取码垛号
        if kdata.palletnum ==0:
            self.twait(0.5)
            goto .x160
        if kdata.palletnum > 32 and kdata.palletnum < 49:
            #位姿定义
            kdata.palletnum2 = kdata.palletnum - 32
            self.point() #aa[palletnum] = SHIFT(aa[palletnum2] BY 0,0,420)
            self.point() #a = aa[palletnum]
            self.point() #POINT pallet[palletnum] = a+cam
            self.point() #POINT/X aguodu = pallet[palletnum]
            self.point() #POINT/OAT aguodu = pallet[palletnum]
            up_limit = 350
            down_limit = -5
            #码垛
            # self.lmove(aguodu)
            # accuracy 1
            # JAPPRO pallet[palletnum], up_limit
            self.signal(237)
            self.signal (- 256)
            # SPEED 100
            # ACCURACY 1
            # LMOVE pallet[palletnum]
            # SPEED 40
            # LAPPRO pallet[palletnum], down_limit
            self.break_()
            self.signal(1, -2)
            self.twait(           0.1)
            self.SWAIT(        1001, -1002)
            self.signal(206)
            #码垛计数
            # SPEED           20
            # LMOVE           pallet[palletnum]
            # ACCURACY             1
            # LAPPRO            pallet[palletnum], up_limit
            self.signal(- 237, -214, 255)
            self.break_()
            # ACCURACY            20
            self.signal( 209)
            #码垛完成
            self.twait(0.1)
        if kdata.palletnum>16 and kdata.palletnum < 33:
            pass
            # palletnum3 = palletnum - 16
            # POINT      aa[palletnum] = SHIFT(aa[palletnum3]
            # BY           0, 0, 210)
            # POINT            a = aa[palletnum]
            # POINT            pallet[palletnum] = a + cam
            # POINT / X            aguodu = aa[palletnum]
            # POINT / OAT            aguodu = aa[palletnum]
            # up_limit = 350
            # down_limit = -5
        if kdata.palletnum > 0 and kdata.palletnum<17:
            pass

    def rpalletnum(self):
        label .x732
        kdata.alletnum = self.bits(1033,8)
        if kdata.palletnum < 0 or kdata.palletnum > 48:
            self.twait(0.5)
            goto .x732
        else:
            print(kdata.palletnum)

    def rmlhnum(self):
        label .x628
        kdata.mlhnum = self.bits(1161,8)
        if kdata.mlhnum <= 0 or kdata.mlhnum > 5:
            self.twait(0.5)
            goto .x628
        else:
            print(kdata.mlhnum)

    def pickc3(self):
        # BASE NULL
        self.tool(kdata.tooltet_k, "tooltet_k")
        self.accuracy(100)
        self.speed(100)
        self.signal(32)
        self.rpalletnum()
        if kdata.palletnum == 0:
            self.rmlhnum()
            self.accuracy(10)
            # lappro dg[]
            self.speed(20)
            # accuracy 1 fine
            # lmove dg
            self.break_()
            self.signal(1, -2, 206)
            self.twait(0.3)
            self.swait(1001, -1002)
            self.accuracy(1)
            # lappro
            self.break_()
            self.signal(206)
        else:
            # lmove
            # jmove
            self.pickf()
            # jmove
            # self.lmove
            self.signal(-32)

    def pickc1(self):
        TOOL = kdata.tooltet_k #tool()
        # ACCURACY 100 ALWAYS
        # SPEED 100 ALWAYS
        self.jmove(kdata._pounce, kdata.jonum)
        self.signal(True, "-1", "2", "-3", "4")
        self.jmove(kdata._guodu, kdata.jonum)
        self.jmove(kdata._tx1, kdata.jonum)
        # ACCURACY 1 FINE
        self.lmove(kdata.tx2, kdata.posnum)
        param=["","",100]
        self.draw(param)
        # ACCURACY 1 FINE
        # SPEED 15
        self.lmove(kdata.tx6, kdata.jonum)
        self.break_()
        self.signal(True, "195")
        self.twait(0.3)
        self.swait(1008,1016,-1009)


        # if self.sig(254) == True and self.sig(1006) == False:
        #     self.bits_assign(18,41,8)
        #     pos = self.bits(41,8)
        #     print(pos)
        # else:
        #     pos = self.bits(1,8)
        #     print(pos)

        # ACCURACY 1 FINE
        self.lmove(kdata.tx8, kdata.jonum)
        self.signal(True, "225")
        self.jmove(kdata.tx9, kdata.jonum)

        self.signal(True, "1", "-2", "214")
        # ACCURACY 50
        self.jmove(kdata._rx1, kdata.jonum)
        # ACCURACY 1 FINE
        # lappro(rx2,posnum,5)
        self.signal(True, "-231")

        self.drive("6", "-370", "60")
        self.signal(True, "-225")
        self.drive("6", "-10", "60")
        # pause()
        if kdata.jonum == 1:
            param = ["",-40,"","","-50","60"]
            self.draw(param)
            # ACCURACY 1 FINE
            # DRAW, -32,, , , , 30
            self.break_()
        else:
            # DRAW, 40,, , 45,, 60 MM / s
            # ACCURACY 1 FINE
            # DRAW, 30,, , , , 30
            self.break_()
        self.signal(True, "3", "-4")
        self.twait(0.5)
        self.signal(True, "221")
        # ACCURACY 1 FINE
        self.drive("6", "25", "50")
        self.here()
        self.break_()

        # ACCURACY 1 ALWAYS
        TOOL = kdata.tooltet_k
        self.tdraw()
        self.signal(True, "222")
        if kdata.jonum == 1:
            # ACCURACY 1 FINE
            # self.draw()
            # self.draw()
            self.signal(True, "238")
            self.break_()
        else:
            # ACCURACY 1 FINE
            # self.draw("", "", 65, "", "", "", 100)
            # self.draw("198", "", "")
            self.signal(True, "238")
            self.break_()
        self.signal(True, "-3", "4")
        # ACCURACY 1 FINE
        self.tdraw()
        self.break_()
        self.signal(True, "-195", "-225", "-238", "-229")
        self.signal(True, "195", "225", "238", "229")
        pos = self.bits(1, 8)

    def work2(self):
        self.signal(-25,26)
        kdata.jobnum = self.bits(41,8)
        self.bits_assign(0,41,8)
        self.signal(26)
        # closei
        self.rposnum()
        self.pickc1()
        self.twait(5)
        self.pickc2()
        self.pickc3()
        pass

    def work3(self):
        pass

    def work4(self):
        pass

    def work5(self):
        pass

    def work6(self):
        pass

    def other(self):
        pass

    def initialize(self):
        pass

    def main(self):
        self.signal(-25)
        label .start
        # home 1
        self.initialize()
        kdata.jobnum = self.bits(1041, 8)
        # jobnum = 2
        # Print
        # switch
        numbers = {
            2: self.work2,
            3: self.work3,
            4: self.work4,
            5: self.work5,
            6: self.work6
        }
        method = numbers.get(kdata.jobnum, self.other)
        if method:
            method()
        goto .start
        # HOME 1
        # STOP